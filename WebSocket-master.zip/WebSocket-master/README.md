# WebSocket
WebSocket示例，HTML和NODE.JS作为客户端，NODE.JS作为服务端，带发送信息，广播信息，回调信息功能

使用方法：
<br>
没有安装nodejs-websocket库的，需要先用npm先安装
<br><br>
npm install -g nodejs-websocket
<br><br>
装好后直接按顺序执行以下命令即可调用示例
<br>
node server.js
<br>
node client.js
<br><br>

HTML示例直接用浏览器打开就可以了，我在PC的Edge、猎豹、Chrome浏览器，以及移动平台上的努比亚Z17、魅族Flyme 6的自带浏览器，iPhone 5s+iOS 10.3 Safari均测试通过
